const path = require('path');
try { require('dotenv').config({ path: path.join(__dirname, '..', '.env') }); } catch (_) {}
// Mitigación temporal para errores TLS en fetch (Supabase): sólo para diagnóstico
try { if (!process.env.NODE_TLS_REJECT_UNAUTHORIZED) { process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; console.warn('⚠️ TLS verification disabled for diagnostics (NODE_TLS_REJECT_UNAUTHORIZED=0)'); } } catch {}
const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const NetworkDiscovery = require(path.join(__dirname, '..', 'SqulInstrucciones', 'networkDiscovery'));
// Logs de diagnóstico de .env
try {
  console.log('📋 Verificando .env:');
  console.log('  SUPABASE_URL:', process.env.SUPABASE_URL ? '✅ OK' : '❌ FALTA');
  console.log('  SUPABASE_ANON_KEY:', process.env.SUPABASE_ANON_KEY ? '✅ OK' : '❌ FALTA');
  console.log('  SUPABASE_SERVICE_ROLE_KEY:', process.env.SUPABASE_SERVICE_ROLE_KEY ? '✅ OK' : '❌ FALTA');
} catch {}
// Importar testSupabase
let testSupabase;
try { ({ testSupabase } = require(path.join(__dirname, '..', 'supabaseClient.js'))); } catch (e) { console.warn('No se pudo cargar testSupabase:', e?.message || e); }

// Desactivar aceleración por GPU para evitar fallos en entornos sin soporte
try {
  app.disableHardwareAcceleration();
  app.commandLine.appendSwitch('disable-gpu');
  app.commandLine.appendSwitch('disable-software-rasterizer');
} catch (_) { /* noop */ }

// Servicios y handlers existentes
let registerIpcHandlers;
let PrinterService;
let PrinterManager;
let Roles;
let discovery = null;
try {
  // Carga dinámica para reutilizar tus módulos actuales
  const { registerIpcHandlers: _registerIpcHandlers } = require(path.join(__dirname, '..', 'src', 'main', 'ipc'));
  registerIpcHandlers = _registerIpcHandlers;
} catch (e) {
  console.warn('No se encontró src/main/ipc:', e.message);
}
try {
  PrinterService = require(path.join(__dirname, '..', 'src', 'main', 'hardware', 'printer'));
} catch (e) {
  console.warn('No se encontró printer service:', e.message);
}
try {
  PrinterManager = require(path.join(__dirname, '..', 'printerManager'));
} catch (e) {
  console.warn('No se pudo cargar PrinterManager:', e.message);
}
try {
  Roles = require(path.join(__dirname, '..', 'src', 'main', 'security', 'roles'));
} catch (e) {
  console.warn('No se encontró roles module, usaré persistencia en SQLite:', e.message);
  // Persistencia de rol en Caja/data/casino.db (tabla configuracion)
  Roles = {
    async getRole() {
      try {
        const Database = require('better-sqlite3');
        const dbPath = path.join(__dirname, '..', 'Caja', 'data', 'casino.db');
        const db = new Database(dbPath);
        db.exec(`
          CREATE TABLE IF NOT EXISTS configuracion (
            clave TEXT PRIMARY KEY,
            valor TEXT,
            actualizado DATETIME DEFAULT CURRENT_TIMESTAMP
          );
        `);
        const row = db.prepare('SELECT valor FROM configuracion WHERE clave = ?').get('rol_actual');
        db.close();
        const role = row?.valor ? String(row.valor).toUpperCase() : 'MESA';
        return role; // Por defecto MESA para evitar accesos de admin
      } catch (err) {
        console.warn('getRole fallback ADMIN:', err?.message || err);
        return 'ADMIN';
      }
    },
    async setRole(r) {
      try {
        const Database = require('better-sqlite3');
        const dbPath = path.join(__dirname, '..', 'Caja', 'data', 'casino.db');
        const db = new Database(dbPath);
        db.exec(`
          CREATE TABLE IF NOT EXISTS configuracion (
            clave TEXT PRIMARY KEY,
            valor TEXT,
            actualizado DATETIME DEFAULT CURRENT_TIMESTAMP
          );
        `);
        const val = String(r || 'MESA').toUpperCase();
        db.prepare('INSERT OR REPLACE INTO configuracion (clave, valor) VALUES (?, ?)')
          .run('rol_actual', val);
        db.close();
        return val;
      } catch (err) {
        console.warn('setRole error, fallback MESA:', err?.message || err);
        return 'MESA';
      }
    }
  };
}

let mainWindow;

function setAppMenu(){
  const template = [
    { label: 'Archivo', submenu: [
        { label: 'Cerrar sesión', accelerator: 'Ctrl+L', click: () => {
            try {
              const win = BrowserWindow.getFocusedWindow();
              win?.webContents.send('logout-request');
            } catch {}
          } },
        { type: 'separator' },
        { label: 'Reiniciar', accelerator: 'Ctrl+Shift+R', click: () => { try { app.relaunch(); app.exit(0); } catch {} } },
        { label: 'Salir', accelerator: 'Alt+F4', click: () => { try { app.quit(); } catch {} } }
      ] },
    { label: 'Ver', submenu: [
        { role: 'reload' },
        { role: 'toggleDevTools' }
      ] },
    { label: 'Ayuda', submenu: [
        { label: 'Acerca de', click: () => { try { dialog.showMessageBox({ type:'info', title:'Acerca de', message:'Sistema de Casino', detail:'Modo Puro (Electron)' }); } catch {} } }
      ] }
  ];
  try {
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
  } catch (e) {
    console.warn('No se pudo establecer menú:', e?.message || e);
  }
}


function createWindow(filePath, opts = {}) {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    autoHideMenuBar: true,
    webPreferences: {
      preload: opts.preloadPath || path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  if (opts.loadURL) {
    win.loadURL(opts.loadURL);
  } else {
    win.loadFile(filePath);
  }
  return win;
}

async function can(view) {
  try {
    const r = String(await Roles.getRole()).toUpperCase();
    if (view === 'mesa') return r === 'MESA' || r === 'ADMIN';
    if (view === 'caja') return r === 'CAJA' || r === 'ADMIN';
    if (view === 'auditoria') return r === 'AUDITOR' || r === 'ADMIN';
    if (view === 'config') return r === 'ADMIN';
    return true;
  } catch (e) {
    console.warn('can(view) fallback MESA:', e.message);
    return true;
  }
}

async function createPanelWindow() {
  if (!await can('panel')) {
    return dialog.showErrorBox('Acceso denegado', 'No tiene permiso para abrir el panel');
  }
  mainWindow = createWindow(path.join(__dirname, '..', 'Caja', 'panel.html'));
}

async function createMesaWindow() {
  if (!await can('mesa')) {
    return dialog.showMessageBox({ type: 'warning', message: 'Acceso solo MESA/ADMIN' });
  }
  createWindow(path.join(__dirname, '..', 'pure', 'mesa.html'));
}

function isCajaEnabled() {
  try {
    // Validación mínima: chequear flag de configuración o que exista al menos un operador activo
    const Database = require('better-sqlite3');
    const dbPath = path.join(__dirname, '..', 'Caja', 'data', 'casino.db');
    const db = new Database(dbPath);
    // Asegura tablas (si no existen) para evitar fallos en SELECT
    db.exec(`
      CREATE TABLE IF NOT EXISTS configuracion (
        clave TEXT PRIMARY KEY,
        valor TEXT,
        actualizado DATETIME DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS operadores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT UNIQUE NOT NULL,
        nombre TEXT NOT NULL,
        pin TEXT NOT NULL,
        mesa_asignada TEXT,
        activo INTEGER DEFAULT 1,
        fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);
    const getCfg = db.prepare('SELECT valor FROM configuracion WHERE clave = ?');
    const row = getCfg.get('caja_habilitada');
    if (row && String(row.valor) === '1') { db.close(); return true; }

    const op = db.prepare('SELECT COUNT(1) as c FROM operadores WHERE activo = 1').get();
    db.close();
    return (op && op.c > 0);
  } catch (e) {
    console.warn('isCajaEnabled() error:', e.message);
    return false;
  }
}

async function createCajaWindow() {
  // Obtener rol actual y validar autorización
  let role = 'MESA';
  try { role = String(await Roles.getRole()).toUpperCase(); } catch {}
  const authorized = (role === 'CAJA' || role === 'ADMIN');
  if (!authorized) {
    try { await dialog.showMessageBox({ type: 'warning', message: 'No está autorizado' }); } catch {}
    return;
  }
  // ADMIN puede entrar aunque la caja no esté habilitada
  if (role !== 'ADMIN' && !isCajaEnabled()) {
    try { await dialog.showMessageBox({ type: 'warning', message: 'Caja no habilitada' }); } catch {}
    return;
  }
  const preloadCaja = path.join(__dirname, '..', 'Caja', 'preload-caja.js');
  createWindow(path.join(__dirname, '..', 'Caja', 'caja.html'), { preloadPath: preloadCaja });
}

async function createAuditWindow() {
  if (!await can('auditoria')) {
    return dialog.showMessageBox({ type: 'warning', message: 'Acceso solo AUDITOR/ADMIN' });
  }
  createWindow(path.join(__dirname, 'auditoria.html'));
}

async function createConfigWindow() {
  if (!await can('config')) {
    return dialog.showMessageBox({ type: 'warning', message: 'Acceso solo ADMIN' });
  }
  createWindow(path.join(__dirname, 'config.html'));
}

// IPC: roles
ipcMain.handle('get-role', async () => {
  try { return await Roles.getRole(); } catch { return 'MESA'; }
});
ipcMain.handle('set-role', async (_e, role) => {
  try { return await Roles.setRole(role); } catch { return 'MESA'; }
});

// IPC: configuración de Caja (habilitar/deshabilitar)
ipcMain.handle('get-caja-enabled', async () => {
  try {
    const Database = require('better-sqlite3');
    const dbPath = path.join(__dirname, '..', 'Caja', 'data', 'casino.db');
    const db = new Database(dbPath);
    db.exec(`
      CREATE TABLE IF NOT EXISTS configuracion (
        clave TEXT PRIMARY KEY,
        valor TEXT,
        actualizado DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);
    const row = db.prepare('SELECT valor FROM configuracion WHERE clave = ?').get('caja_habilitada');
    db.close();
    return !!(row && String(row.valor) === '1');
  } catch (e) {
    console.error('get-caja-enabled error:', e);
    return false;
  }
});

ipcMain.handle('set-caja-enabled', async (_e, enabled) => {
  try {
    const Database = require('better-sqlite3');
    const dbPath = path.join(__dirname, '..', 'Caja', 'data', 'casino.db');
    const db = new Database(dbPath);
    db.exec(`
      CREATE TABLE IF NOT EXISTS configuracion (
        clave TEXT PRIMARY KEY,
        valor TEXT,
        actualizado DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);
    const val = enabled ? '1' : '0';
    db.prepare('INSERT OR REPLACE INTO configuracion (clave, valor) VALUES (?, ?)').run('caja_habilitada', val);
    db.close();
    return { success: true, enabled: !!enabled };
  } catch (e) {
    console.error('set-caja-enabled error:', e);
    return { success: false, error: e.message };
  }
});

// Inicialización de servicios y registro de handlers
function initServicesAndHandlers() {
  try {
    if (registerIpcHandlers) {
      const printer = PrinterService ? new PrinterService() : null;
      // Inicializar DB y sincronización si están disponibles
      let db = null; let supabaseSync = null;
      // Unificar uso de base de datos: preferir CasinoDatabase (SqulInstrucciones)
      try { const CasinoDatabase = require(path.join(__dirname, '..', 'SqulInstrucciones', 'database')); db = new CasinoDatabase(); }
      catch (e) {
        console.warn('CasinoDatabase no disponible, intentando SQLiteDB:', e.message);
        try { const SQLiteDB = require(path.join(__dirname, '..', 'src', 'main', 'database', 'sqlite')); db = new SQLiteDB(); } catch (e2) { console.warn('SQLiteDB no disponible:', e2.message); }
      }
      try { const SupabaseSync = require(path.join(__dirname, '..', 'src', 'main', 'database', 'supabase')); supabaseSync = new SupabaseSync(); } catch (e) { console.warn('SupabaseSync no disponible:', e.message); }

      // Compatibilidad adicional: si fallara, usar DB de Caja como último recurso
      if (!db) {
        try { const CajaDB = require(path.join(__dirname, '..', 'Caja', 'database')); db = new CajaDB(); } catch (e3) { console.warn('CajaDB no disponible:', e3.message); }
      }

      // Fallback definitivo: DB en memoria para vouchers/tickets si todas las opciones fallan
      if (!db) {
        console.warn('DB no disponible, activando fallback en memoria para vouchers/tickets');
        const memoryStore = {
          vouchersByCode: new Map(),
          vouchersById: new Map(),
          idSeq: 1
        };
        db = {
          createVoucher(amount, currency, userId, stationId, customerName = null) {
            const id = String(memoryStore.idSeq++);
            const code = `V${Date.now()}`;
            const voucher = {
              id,
              voucher_code: code,
              qr_data: null,
              qr_hash: null,
              amount,
              currency,
              status: 'active',
              issued_by_user_id: userId || 'OFFLINE',
              issued_at_station_id: stationId || 1,
              issued_at: new Date().toISOString(),
              redeemed_by_user_id: null,
              redeemed_at_station_id: null,
              redeemed_at: null,
              expires_at: new Date(Date.now() + 24*60*60*1000).toISOString(),
              customer_name: customerName,
              customer_notes: null,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              synced: 0
            };
            memoryStore.vouchersByCode.set(code, voucher);
            memoryStore.vouchersById.set(id, voucher);
            return voucher;
          },
          getVoucherByCode(code) {
            return memoryStore.vouchersByCode.get(String(code));
          },
          updateTicketStatus(ticketNumber, estado, usuario_canje = null) {
            const v = memoryStore.vouchersByCode.get(String(ticketNumber));
            if (!v) return { changes: 0 };
            // Mapear estados legacy a status moderno
            const statusMap = {
              'emitido': 'active',
              'activo': 'active',
              'canjeado': 'redeemed',
              'expirado': 'expired',
              'cancelado': 'cancelled'
            };
            const newStatus = statusMap[estado] || 'redeemed';
            v.status = newStatus;
            v.redeemed_by_user_id = usuario_canje || 'OFFLINE';
            v.redeemed_at_station_id = 1;
            v.redeemed_at = newStatus === 'redeemed' ? new Date().toISOString() : null;
            v.updated_at = new Date().toISOString();
            return { changes: 1 };
          },
          _mapVoucherStatusToEstado(status) {
            const map = {
              'active': 'emitido',
              'redeemed': 'canjeado',
              'expired': 'expirado',
              'cancelled': 'cancelado'
            };
            return map[status] || 'emitido';
          },
          getTicketStats() {
            // Estadísticas básicas en memoria
            let activos = 0, canjeados = 0, total_dop = 0, total_usd = 0;
            for (const v of memoryStore.vouchersByCode.values()) {
              if (v.status === 'active') activos++;
              if (v.status === 'redeemed') canjeados++;
              if (v.currency === 'DOP') total_dop += v.amount;
              if (v.currency === 'USD') total_usd += v.amount;
            }
            return { activos, canjeados, total_dop, total_usd };
          }
        };
      }

      // Activar sincronización Supabase cada 30s si está habilitado por entorno
      try {
        const useSupabase = String(process.env.USE_SUPABASE || '').toLowerCase() === 'true';
        if (useSupabase && db) {
          const { createClient } = require('@supabase/supabase-js');
          const supabase = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_SERVICE_ROLE_KEY
          );
          // Sincronizar usuarios de Supabase a SQLite local
          const syncUsers = async () => {
            try {
              console.log('🔄 Sincronizando usuarios...');
              const { data: supabaseUsers, error } = await supabase
                .from('users')
                .select('*');
              if (error) throw error;
              if (Array.isArray(supabaseUsers) && supabaseUsers.length > 0) {
                // Usar API de CasinoDatabase para poblar tabla local 'usuarios'
                for (const u of supabaseUsers) {
                  try {
                    const email = u.email || u.username;
                    if (!email) continue;
                    const existing = (typeof db.getUserByUsername === 'function') ? db.getUserByUsername(email) : null;
                    // Mapear role y activo
                    const role = String(u.role || 'MESA').toUpperCase();
                    const activo = u.is_active ? 1 : 0;
                    const pin = u.pin_code || 'changeme1234';
                    if (!existing) {
                      // Crear usuario local con pin como contraseña
                      if (typeof db.createUser === 'function') {
                        db.createUser(email, pin, role, activo, email);
                      }
                    } else {
                      // Actualizar role/activo y contraseña si hay pin_code
                      if (typeof db.setUserRole === 'function') db.setUserRole(existing.id, role);
                      if (typeof db.setUserActive === 'function') db.setUserActive(existing.id, !!activo);
                      if (u.pin_code && typeof db.setUserPassword === 'function') db.setUserPassword(existing.id, pin);
                    }
                  } catch (e) {
                    console.warn('Sync usuario falló:', e?.message || e);
                  }
                }
                // Conteo de usuarios locales
                try {
                  const sqlite = (db && db.db && typeof db.db.prepare === 'function') ? db.db : null;
                  const usersCount = sqlite ? sqlite.prepare('SELECT COUNT(*) as count FROM usuarios').get() : { count: 'N/D' };
                  console.log(`✅ ${supabaseUsers.length} usuarios sincronizados de Supabase | 📊 Usuarios en SQLite(usuarios): ${usersCount.count}`);
                } catch { console.log(`✅ ${supabaseUsers.length} usuarios sincronizados de Supabase`); }
              } else {
                console.log('ℹ️ No hay usuarios para sincronizar desde Supabase');
              }
            } catch (err) {
              console.error('❌ Error sincronizando usuarios:', err?.message || String(err));
            }
          };
          // Sincronizar al inicio (sin await)
          try { syncUsers().catch(() => {}); } catch {}
          // Sincronizar cada 5 minutos
          setInterval(syncUsers, 300000);
          setInterval(async () => {
            try {
              const pending = typeof db.getPendingSyncQueue === 'function' ? db.getPendingSyncQueue() : [];
              for (const item of pending) {
                const data = JSON.parse(item.record_data);
                if (item.table_name === 'vouchers') {
                  await supabase.from('vouchers').upsert(data);
                  if (typeof db.markSynced === 'function') db.markSynced(item.id);
                }
              }
              console.log('✅ Sync OK');
            } catch (error) {
              console.error('❌ Sync error:', error);
            }
          }, 30000);
        }
      } catch (e) {
        console.warn('Supabase sync init error:', e?.message || e);
      }

      registerIpcHandlers({ db, supabaseSync, printer });
      console.log('IPC Handlers registrados (modo puro).');

      // Handlers directos de impresión (voucher) si no existen en src/main/ipc
      if (PrinterManager) {
        const pm = new PrinterManager();
        ipcMain.handle('print-voucher', async (_e, voucher) => {
          try { return await pm.printVoucher(voucher); } catch (err) { return { success:false, error: err?.message || String(err) }; }
        });
        ipcMain.handle('test-print', async () => {
          try { return await pm.test(); } catch (err) { return { success:false, error: err?.message || String(err) }; }
        });
      }
    }
  } catch (e) {
    console.error('Error registrando handlers:', e);
  }

  // Registrar handlers específicos de Caja (IPC namespace caja:*)
  try {
    const { registerCajaHandlers } = require(path.join(__dirname, '..', 'Caja', 'cajaHandlers'));
    registerCajaHandlers();
    console.log('Handlers de Caja registrados.');
  } catch (e) {
    console.warn('No se pudieron registrar handlers de Caja:', e.message);
  }

  // Registrar handlers de Autenticación (auth:*)
  try {
    const { registerAuthHandlers } = require(path.join(__dirname, 'authHandlers'));
    // Registrar handlers REALES (sin fallback)
    registerAuthHandlers();
    console.log('✅ Auth handlers REALES registrados');
  } catch (e) {
    console.warn('No se pudieron registrar handlers de Autenticación:', e.message);
  }

  // Fallback: registrar handlers mínimos si los módulos anteriores fallan
  try {
    // Fallbacks offline de auth desactivados intencionalmente para usar handlers REALES
    // Mantén solo fallbacks no relacionados con auth si fueran necesarios
    if (!ipcMain._events || !ipcMain._events['caja:get-stats-today']) {
      ipcMain.handle('caja:get-stats-today', async () => ({
        total: 0,
        total_usd: 0,
        total_dop: 0,
        activos: 0,
        canjeados: 0
      }));
    }
  } catch (e) {
    console.warn('No se pudieron registrar fallbacks de handlers (offline no-auth):', e?.message || e);
  }

  // --- Reemplazar handler de auth:login con validación REAL contra SQLite ---
  try {
    // Anula cualquier handler previo para evitar colisiones
    try { ipcMain.removeHandler('auth:login'); } catch {}
    const crypto = require('crypto');
    const sqlite = (db && db.db && typeof db.db.prepare === 'function') ? db.db : null;
    ipcMain.handle('auth:login', async (_event, { username, password }) => {
      console.log('=================================');
      console.log('🔐 AUTH:LOGIN REAL LLAMADO');
      console.log('Usuario:', username);
      console.log('=================================');
      try {
        if (!username || !password) {
          return { success: false, error: 'Usuario y contraseña requeridos' };
        }
        // Buscar usuario
        let userRow;
        if (sqlite) {
          userRow = sqlite.prepare(
            'SELECT * FROM usuarios WHERE (username = ? OR email = ?) AND activo = 1'
          ).get(String(username).trim(), String(username).trim());
        } else if (typeof db.getUserByUsername === 'function') {
          userRow = db.getUserByUsername(String(username).trim());
          if (userRow && !userRow.activo) userRow = null;
        }
        if (!userRow) {
          console.log('❌ Usuario no encontrado o inactivo:', username);
          return { success: false, error: 'Usuario no encontrado o inactivo' };
        }
        console.log('✅ Usuario encontrado:', userRow.username);
        console.log('   Role:', userRow.role);

        const hashed = crypto.pbkdf2Sync(
          String(password),
          Buffer.from(userRow.password_salt, 'hex'),
          100000,
          64,
          'sha512'
        ).toString('hex');
        if (hashed !== userRow.password_hash) {
          console.log('❌ PIN incorrecto');
          return { success: false, error: 'PIN incorrecto' };
        }

        // Actualizar last_login
        try {
          if (sqlite) {
            sqlite.prepare('UPDATE usuarios SET last_login = CURRENT_TIMESTAMP WHERE id = ?').run(userRow.id);
          } else if (typeof db.setUserPassword === 'function') {
            // no-op para last_login si no hay acceso sqlite directo
          }
        } catch (e) { console.warn('No se pudo actualizar last_login:', e?.message || e); }

        console.log('✅ Login exitoso:', userRow.username);
        return {
          success: true,
          user: {
            id: userRow.id,
            email: userRow.email || userRow.username,
            name: userRow.username,
            role: userRow.role
          }
        };
      } catch (error) {
        console.error('❌ Error en auth:login:', error?.message || String(error));
        return { success: false, error: error?.message || String(error) };
      }
    });
    console.log('✅ Handler auth:login REAL registrado');
  } catch (e) {
    console.error('No se pudo registrar AUTH:LOGIN REAL:', e?.message || e);
  }
}

// Inicializar descubrimiento de red y exponer IPC
function initNetworkDiscovery() {
  try {
    const cfg = {
      port: process.env.DISCOVERY_PORT ? parseInt(process.env.DISCOVERY_PORT) : 3001,
      serverPort: process.env.SERVER_PORT ? parseInt(process.env.SERVER_PORT) : 3000,
      isServer: process.env.IS_SERVER === 'true',
      stationId: process.env.STATION_ID ? parseInt(process.env.STATION_ID) : null,
      stationName: process.env.STATION_NAME || (process.env.IS_SERVER === 'true' ? 'Caja Principal' : 'Estación Casino'),
      stationType: process.env.STATION_TYPE || (process.env.IS_SERVER === 'true' ? 'caja' : 'mesa')
    };
    discovery = new NetworkDiscovery(cfg);

    // Eventos informativos
    discovery.on('station-found', (station) => {
      console.log(`station-found: ${station.name} (${station.ip})`);
      try { BrowserWindow.getAllWindows().forEach(w => w.webContents.send('station-found', station)); } catch (_) {}
    });
    discovery.on('station-lost', (station) => {
      console.log(`station-lost: ${station.name} (${station.ip})`);
      try { BrowserWindow.getAllWindows().forEach(w => w.webContents.send('station-lost', station)); } catch (_) {}
    });
    discovery.on('error', (err) => {
      console.warn('NetworkDiscovery error:', err?.message || String(err));
    });

    discovery.start().then(() => {
      console.log('NetworkDiscovery iniciado:', discovery.getMyInfo());
    }).catch((e) => {
      console.error('NetworkDiscovery start error:', e?.message || String(e));
    });

    // IPC endpoints
    ipcMain.handle('network:get-stations', async () => {
      try { return discovery ? discovery.getStations() : []; } catch (e) { return []; }
    });
    ipcMain.handle('network:get-server-url', async () => {
      try { return discovery ? discovery.getServerURL() : null; } catch (e) { return null; }
    });
    ipcMain.handle('network:get-stats', async () => {
      try { return discovery ? discovery.getStats() : { total: 0, byType: {}, hasServer: false }; } catch (e) { return { total: 0, byType: {}, hasServer: false }; }
    });
    ipcMain.handle('network:get-my-info', async () => {
      try { return discovery ? discovery.getMyInfo() : null; } catch (e) { return null; }
    });
  } catch (e) {
    console.warn('initNetworkDiscovery error:', e?.message || String(e));
  }
}

app.whenReady().then(async () => {
  initServicesAndHandlers();
  initNetworkDiscovery();
  setAppMenu();
  await createPanelWindow();

  // Probar conexión a Supabase al inicio
  try {
    if (typeof testSupabase === 'function') {
      const ok = await testSupabase();
      console.log('🔎 testSupabase resultado:', ok ? 'OK' : 'FALLÓ');
    }
  } catch (e) {
    console.error('Error en testSupabase:', e?.message || e);
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createPanelWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  try {
    if (discovery) {
      discovery.stop();
    }
  } catch (_) {}
});

// Opcional: abre ventanas desde panel vía IPC (si lo usas)
ipcMain.handle('open-view', async (_e, view) => {
  if (view === 'mesa') return createMesaWindow();
  if (view === 'caja') return createCajaWindow();
  if (view === 'auditoria') return createAuditWindow();
  if (view === 'config') return createConfigWindow();
});

// Enfocar la ventana de Panel; si no existe, crearla
ipcMain.handle('focus-panel', async () => {
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
      return { success: true };
    }
    await createPanelWindow();
    if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
    return { success: true, created: true };
  } catch (e) {
    return { success: false, error: e?.message || String(e) };
  }
});

// Cerrar la ventana desde la que se invoca
ipcMain.handle('close-current', async (event) => {
  try {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (win && !win.isDestroyed()) {
      win.close();
      return { success: true };
    }
    return { success: false, error: 'No se encontró ventana actual' };
  } catch (e) {
    return { success: false, error: e?.message || String(e) };
  }
});
